Uize.module('Site.Widgets');
